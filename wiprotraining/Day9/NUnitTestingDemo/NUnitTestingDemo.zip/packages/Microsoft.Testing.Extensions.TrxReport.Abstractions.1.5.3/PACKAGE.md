# Microsoft.Testing

Microsoft Testing is a set of platform, framework and protocol intended to make it possible to run any test on any target or device.

Documentation can be found at <https://aka.ms/testingplatform>.

## About

This package provides interfaces and data objects used by extensions willing to interoperate with TRX functionality.

This package does not bring support for telemetry, for this you would need to install Microsoft.Testing.Extensions.TrxReport package.
