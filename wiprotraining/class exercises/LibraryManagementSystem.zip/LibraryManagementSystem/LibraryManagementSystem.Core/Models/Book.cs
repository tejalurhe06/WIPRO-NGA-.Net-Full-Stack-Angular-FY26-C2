using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Core.Models
{
    public class Book
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Title is required")]
        [StringLength(200, ErrorMessage = "Title cannot be longer than 200 characters")]
        public string Title { get; set; }
        
        [Required(ErrorMessage = "ISBN is required")]
        [StringLength(20, ErrorMessage = "ISBN cannot be longer than 20 characters")]
        public string ISBN { get; set; }
        
        [StringLength(1000, ErrorMessage = "Description cannot be longer than 1000 characters")]
        public string Description { get; set; }
        
        [Required(ErrorMessage = "Published Date is required")]
        [DataType(DataType.Date)]
        public DateTime PublishedDate { get; set; }
        
        [Required(ErrorMessage = "Author is required")]
        [Display(Name = "Author")]
        public int AuthorId { get; set; }
        
        [ForeignKey("AuthorId")]
        public Author Author { get; set; }
        
        [Required(ErrorMessage = "Genre is required")]
        [Display(Name = "Genre")]
        public int GenreId { get; set; }
        
        [ForeignKey("GenreId")]
        public Genre Genre { get; set; }
    }
}