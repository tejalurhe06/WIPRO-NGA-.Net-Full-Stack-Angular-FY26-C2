﻿namespace LibraryManagementSystem.Core;

public class Class1
{

}
