namespace ShopForHome.API.DTOs
{
    public class PriceUpdateRequest
    {
                public decimal PercentageChange { get; set; }
    }
}