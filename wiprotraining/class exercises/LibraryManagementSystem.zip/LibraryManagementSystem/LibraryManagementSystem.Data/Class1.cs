﻿namespace LibraryManagementSystem.Data;

public class Class1
{

}
